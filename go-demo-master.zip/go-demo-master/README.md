# go-demo
A light-weight example of using Docker Compose with Jenkins for CI/CD with a simple Go app.
